# Jupiter 2011 (Forge 1.20.1)

Build: download Forge MDK 1.20.1-47.x, replace its `src/` with this `src/`,
set `mod_id=jupiter2011` in gradle.properties, run `gradlew build`.

Play: creative tab "Jupiter 2011": Jupiter Rocket (right click -> Jupiter, again -> home),
Astronaut Pistol (right click shoots), Key Spawn Egg. Keys drop Cursed Keys.
