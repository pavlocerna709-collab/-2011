package com.jupiter2011;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(Jupiter2011.MODID)
public class Jupiter2011 {
    public static final String MODID = "jupiter2011";
    public static final ResourceKey<Level> JUPITER =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(MODID, "jupiter"));

    public Jupiter2011() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
    }
}
