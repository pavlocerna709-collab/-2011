package com.jupiter2011;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws the key entity as a big floating, wobbling item. */
public class KeyRenderer extends EntityRenderer<KeyEntity> {
    private final ItemRenderer itemRenderer;

    public KeyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
        this.shadowRadius = 0.3f;
    }

    @Override
    public void render(KeyEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        float t = e.tickCount + partial;
        ps.translate(0.0, 0.7 + Math.sin(t * 0.2) * 0.05, 0.0);
        ps.mulPose(Axis.YP.rotationDegrees(180.0f - Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot)));
        ps.mulPose(Axis.ZP.rotationDegrees((float) Math.sin(t * 0.5) * 12.0f));
        ps.scale(2.2f, 2.2f, 2.2f);
        itemRenderer.renderStatic(new ItemStack(ModItems.CURSED_KEY.get()), ItemDisplayContext.FIXED,
                light, OverlayTexture.NO_OVERLAY, ps, buf, e.level(), e.getId());
        ps.popPose();
        super.render(e, yaw, partial, ps, buf, light);
    }

    @Override
    public ResourceLocation getTextureLocation(KeyEntity e) {
        return InventoryMenu.BLOCK_ATLAS;
    }
}
