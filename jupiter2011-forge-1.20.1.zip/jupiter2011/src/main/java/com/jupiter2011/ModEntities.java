package com.jupiter2011;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Jupiter2011.MODID);

    public static final RegistryObject<EntityType<KeyEntity>> KEY = ENTITIES.register("key",
            () -> EntityType.Builder.of(KeyEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 0.9f)
                    .clientTrackingRange(8)
                    .build("key"));
}
