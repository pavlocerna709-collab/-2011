package com.jupiter2011;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Jupiter2011.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Jupiter2011.MODID);

    public static final RegistryObject<Item> CURSED_KEY =
            ITEMS.register("cursed_key", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PISTOL =
            ITEMS.register("astronaut_pistol", () -> new PistolItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROCKET =
            ITEMS.register("jupiter_rocket", () -> new RocketItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> KEY_SPAWN_EGG =
            ITEMS.register("key_spawn_egg",
                    () -> new ForgeSpawnEggItem(ModEntities.KEY, 0xC0C0C0, 0xFFD700, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.jupiter2011"))
                    .icon(() -> new ItemStack(ROCKET.get()))
                    .displayItems((params, out) -> {
                        out.accept(ROCKET.get());
                        out.accept(PISTOL.get());
                        out.accept(CURSED_KEY.get());
                        out.accept(KEY_SPAWN_EGG.get());
                    })
                    .build());
}
