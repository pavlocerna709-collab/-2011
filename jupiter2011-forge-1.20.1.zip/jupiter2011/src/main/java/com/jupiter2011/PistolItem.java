package com.jupiter2011;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Hitscan pistol: right-click to shoot the keys. */
public class PistolItem extends Item {
    private static final double RANGE = 40.0;
    private static final float DAMAGE = 8.0f;

    public PistolItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && level instanceof ServerLevel sl) {
            level.playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_SHOOT,
                    SoundSource.PLAYERS, 1.0f, 1.6f);

            Vec3 eye = player.getEyePosition();
            Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
            BlockHitResult block = level.clip(new ClipContext(eye, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (block.getType() != HitResult.Type.MISS) {
                end = block.getLocation();
            }
            AABB box = new AABB(eye, end).inflate(1.0);
            EntityHitResult hit = ProjectileUtil.getEntityHitResult(level, player, eye, end, box,
                    e -> !e.isSpectator() && e.isPickable());
            if (hit != null) {
                end = hit.getLocation();
                hit.getEntity().hurt(level.damageSources().playerAttack(player), DAMAGE);
                sl.sendParticles(ParticleTypes.CRIT, end.x, end.y, end.z, 8, 0.2, 0.2, 0.2, 0.1);
            }

            Vec3 dir = end.subtract(eye);
            int steps = (int) dir.length();
            for (int i = 2; i <= steps; i++) {
                Vec3 p = eye.add(dir.scale(i / (double) steps));
                sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }
        player.getCooldowns().addCooldown(this, 8);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
