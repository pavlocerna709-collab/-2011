package com.jupiter2011;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/** Right-click: fly to Jupiter. Right-click on Jupiter: fly home. */
public class RocketItem extends Item {
    public RocketItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            boolean toJupiter = level.dimension() != Jupiter2011.JUPITER;
            ResourceKey<Level> targetKey = toJupiter ? Jupiter2011.JUPITER : Level.OVERWORLD;
            ServerLevel dest = sp.server.getLevel(targetKey);
            if (dest != null) {
                BlockPos base = toJupiter ? BlockPos.ZERO : dest.getSharedSpawnPos();
                int y = dest.getHeight(Heightmap.Types.MOTION_BLOCKING, base.getX(), base.getZ());
                sp.teleportTo(dest, base.getX() + 0.5, y + 1, base.getZ() + 0.5, sp.getYRot(), sp.getXRot());
                sp.displayClientMessage(Component.translatable(
                        toJupiter ? "message.jupiter2011.arrived" : "message.jupiter2011.returned"), true);
                player.getCooldowns().addCooldown(this, 100);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
